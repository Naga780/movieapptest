package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {

    public WebDriver driver;
    public WebDriverWait wait;

    WebElement logoElement;

    @FindBy(className = "sign-in-heading") WebElement headingWlement;

    @FindBy(id = "usernameInput") WebElement userEle;

    @FindBy(id = "passwordInput") WebElement passwordEle;

    @FindBy(className = "login-button") WebElement loginbutton;

    @FindBy(className = "error-message") WebElement errorMsg;

    WebElement userLabel;

    WebElement passwordLable;

    public LoginPage(WebDriver driver){
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        PageFactory.initElements(driver, this);
        logoElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("login-button")));
        userLabel = driver.findElement(By.xpath("/html/body/div/div/div[2]/form/div[1]/input"));
        passwordLable = driver.findElement(By.xpath("/html/body/div/div/div[2]/form/div[2]/input"));
    }

    public boolean checkthelogoelement(){ return logoElement.isDisplayed();}
    public String checktheHeadingelement(){ return headingWlement.getText();}
    public String checkusernNamelabel(){ return userLabel.getText();}
    public String checkpasswordlable(){ return passwordLable.getText();}
    public boolean checkloginbtn(){
        boolean isClickable = loginbutton.isEnabled() && loginbutton.isDisplayed();
        return isClickable;
    }

    public String errorMsg(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("error-message")));
        return errorMsg.getText();
    }

    public void LogintoApplication(String username, String password){
        userEle.sendKeys(username);
        passwordEle.sendKeys(password);
        loginbutton.click();
    }
}
