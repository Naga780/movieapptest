import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.AccountPage;

import java.time.Duration;


public class AccountPageTest {
    public WebDriver driver;
    public WebDriverWait wait;
    public AccountPage accountPage;

    @BeforeMethod
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Naga\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech");
        accountPage = new AccountPage(driver);
    }

    @AfterMethod
    public void setdown(){
        driver.quit();
    }

    @Test

    public void webPageUiTest(){
        accountPage.LoginToApplication("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        //Home Header Sections
        WebElement homeLink = driver.findElement(By.xpath("//a[contains(text(), 'Home')]"));
        homeLink.click();
        String homepage = driver.getCurrentUrl();
        Assert.assertEquals(homepage, "https://qamoviesapp.ccbp.tech/", "Not Navigate to Home Page");

        //Popular Header Section
        WebElement popularHeadingSection = driver.findElement(By.xpath("//a[contains(text(), 'Popular')]"));
        popularHeadingSection.click();
        String popularPage = driver.getCurrentUrl();
        Assert.assertEquals(popularPage,"https://qamoviesapp.ccbp.tech/popular", "Not Navigate to Popular Page");

        //Search Header Section
        WebElement searchHeaderSection = driver.findElement(By.className("search-empty-button"));
        searchHeaderSection.click();
        String searchPage = driver.getCurrentUrl();
        Assert.assertEquals(searchPage,"https://qamoviesapp.ccbp.tech/search", "Not Navigate to Search Page");

        //Account Header Section
        WebElement accountHeaderSection = driver.findElement(By.className("avatar-button"));
        accountHeaderSection.click();
        String accountsPage = driver.getCurrentUrl();
        Assert.assertEquals(accountsPage,"https://qamoviesapp.ccbp.tech/account", "Not Navigate to Accounts Page");
    }
}
