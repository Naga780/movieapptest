import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pages.HomePage;

import java.time.Duration;


public class HeaderPageTest {
    public static WebDriver driver;
    //public WebDriverWait wait;
    public HomePage headerpage;

    @BeforeMethod
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Naga\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech");
        headerpage = new HomePage(driver);
    }

    @AfterMethod
    public void setdown(){
        driver.quit();
    }
    @Test(priority = 1)
    public void checkTheLogoElement(){
        headerpage.LoginToApplication("rahul", "rahul@2021") ;
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        Assert.assertTrue(headerpage.isLogoElementLocated(), "Logo Element Not Found");
    }

    @Test(priority = 2)
    public void checkTheNavBars(){
        headerpage.LoginToApplication("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));


        Assert.assertTrue(headerpage.isHomeNavbarDisplayed(), "Home Page Navbar is Not Working as expected");
        Assert.assertTrue(headerpage.isPopularNavBarDisplayed(), "Popular Page Navbar is Not Working as expected");
        Assert.assertTrue(headerpage.isAccountNavBarDisplayed(), "Account Page Navbar is Not Working as expected");
        Assert.assertTrue(headerpage.isSerachNavBarDisplayed(), "Search Button Navbar is Not Working as expected");
        Assert.assertEquals(headerpage.testPopularHeading(), "Popular");
        Assert.assertTrue(headerpage.testPlayButton(), "Play button section is Not Working as expected");
        Assert.assertTrue(headerpage.testContactUsSection(), "contact us section is Not Working as expected");
        Assert.assertTrue(headerpage.checkMoviesSections(), "movie section is Not Working as expected");
    }

    @Test(priority = 3)
    public void checkTheNavigationFunvtionalities(){
        headerpage.LoginToApplication("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        //Home Header Section
        WebElement homeLink = driver.findElement(By.xpath("//a[contains(text(), 'Home')]"));
        homeLink.click();
        String homepage = driver.getCurrentUrl();
        Assert.assertEquals(homepage,"https://qamoviesapp.ccbp.tech/", "Not Navigate to Homepage");

        //Popular Header Section
        WebElement popularHeaderSection = driver.findElement(By.xpath("//a[contains(text(), 'Popular')]"));
        popularHeaderSection.click();
        String popularPage = driver.getCurrentUrl();
        Assert.assertEquals(popularPage,"https://qamoviesapp.ccbp.tech/popular", "Not Navigate to Popularpage");

        //Search Header Section
        WebElement searchHeaderSection = driver.findElement(By.className("search-empty-button"));
        searchHeaderSection.click();
        String searchPage = driver.getCurrentUrl();
        Assert.assertEquals(searchPage,"https://qamoviesapp.ccbp.tech/search", "Not Navigate to searchpage");

        //Account Header Section
        WebElement accountHeaderSection = driver.findElement(By.className("avatar-button"));
        accountHeaderSection.click();
        String accountPage = driver.getCurrentUrl();
        Assert.assertEquals(accountPage,"https://qamoviesapp.ccbp.tech/account", "Not Navigate to accountpage");

    }

}
