import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;


public class LoginPageTest {
    public WebDriver driver;
    public WebDriverWait wait;
    LoginPage loginPage;

    @BeforeMethod
    public void setup(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Naga\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech");
        loginPage = new LoginPage(driver);

    }

    @AfterMethod
    public void setdown(){
        driver.quit();
    }

    @Test
    public void checkthelogoelement(){
        boolean logoElement = loginPage.checkthelogoelement();
        if(logoElement){
            System.out.println("Logo Element checked Successfully");
        }
        else{
            System.out.println("Login page logo failed");
        }
    }

    @Test
    public void checkHeadingElement(){
        String mainHeading = loginPage.checktheHeadingelement();
        Assert.assertEquals(mainHeading, "Login", "Main heading");

    }

    @Test
    public void checkthelabelElementTexts(){
        String userLabel = loginPage.checkusernNamelabel();
        String passwordLabel = loginPage.checkpasswordlable();
        if(userLabel.equals("USERNAME") && passwordLabel.equals("PASSWORD")){
            System.out.println("Both Labels are Matched Successfully");
        }
        else{
            System.out.println("Both Labels are Not Matched");
        }
    }


    @Test
    public void checktheloginbtn(){
        boolean value = loginPage.checkloginbtn();
        if(value){
            System.out.println("Login btn checked successfully");
        }
        else{
            System.out.println("Login btn failed");
        }
    }


    @Test(priority = 1)
    public void testLoginwithEmptyInputs(){
        loginPage.LogintoApplication("","");
        String errorMsg = loginPage.errorMsg();
        System.out.println(errorMsg);
        Assert.assertEquals(errorMsg,"*Username or password is invalid");
    }


    @Test(priority = 2)
    public void testLoginwithEmptyUsername(){
        loginPage.LogintoApplication("","rahul@2021");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String errorMsg = loginPage.errorMsg();
        Assert.assertEquals(errorMsg,"*Username or password is invalid");
    }


    @Test(priority = 3)
    public void testLoginWithEmptyPassword(){
        loginPage.LogintoApplication("rahul","");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String errorMsg = loginPage.errorMsg();
        Assert.assertEquals(errorMsg,"*Username or password is invalid");
    }

    @Test(priority = 4)
    public void testLoginWithInvalidUsername(){
        loginPage.LogintoApplication("RAHUL","rahul@2021");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String errorMsg = loginPage.errorMsg();
        Assert.assertEquals(errorMsg,"*invalid username");
    }


    @Test(priority = 5)
    public void testLoginWithInvalidPassword(){
        loginPage.LogintoApplication("rahul","rahul2021");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        String errorMsg = loginPage.errorMsg();
        Assert.assertEquals(errorMsg,"*username and password didn't match");
    }

    @Test(priority = 5)
    public void testLoginWithValidUsername(){
        loginPage.LogintoApplication("rahul","rahul@2021");
        String expectedUrl = "https://qamoviesapp.ccbp.tech/";
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.urlToBe(expectedUrl));
        String currentUrl = driver.getCurrentUrl();
        if(currentUrl.equals(expectedUrl)){
            System.out.println("Navigation to home page was successful!");
        }
    }
}
