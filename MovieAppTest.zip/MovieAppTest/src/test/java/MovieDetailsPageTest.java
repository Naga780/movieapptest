import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.MovieDetailsPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class MovieDetailsPageTest {

    public static WebDriver driver;
    public MovieDetailsPage moviedetailspage;

    @BeforeMethod
    public void setUp(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Naga\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech");
        moviedetailspage = new MovieDetailsPage(driver);
    }

    @AfterMethod
    public void setdown() {
        driver.quit();
    }

    @Test
    public void MoviepageUitest(){
        moviedetailspage.LoginToApplications("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        WebElement homepage = driver.findElement(By.xpath("/html/body/div/div/div[2]/div[1]/div/div"));
        homepage.click();

        Assert.assertTrue(moviedetailspage.isMovieHeadingDisplayed(), "Heading not working as expected");

        Assert.assertTrue(moviedetailspage.isMovieReviewDisplayed(), "Review not working as expected");

        Assert.assertTrue(moviedetailspage.isMovieOverviewDisplayed(), "Overview not working as expected");

        Assert.assertTrue(moviedetailspage.isMoviePlayButtonDisplayed(), "Playbutton not working as expected");

        Assert.assertTrue(moviedetailspage.isMovieCategotiesDisplayed(), "Categories not working as expected");

    }

    @Test
    public void popularPageUitest(){
        moviedetailspage.LoginToApplications("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        WebElement popularPage = driver.findElement(By.xpath("//a[contains(text(), 'Popular')]"));
        popularPage.click();


        WebElement venomMvpage = driver.findElement(By.xpath("/html/body/div/div/div[1]/li[1]/a/img"));
        venomMvpage.click();

        Assert.assertTrue(moviedetailspage.isMovieHeadingDisplayed(), "Heading not working as expected");

        Assert.assertTrue(moviedetailspage.isMovieReviewDisplayed(), "Review not working as expected");

        Assert.assertTrue(moviedetailspage.isMovieOverviewDisplayed(), "Overview not working as expected");

        Assert.assertTrue(moviedetailspage.isMoviePlayButtonDisplayed(), "Playbutton not working as expected");

        Assert.assertTrue(moviedetailspage.isMovieCategotiesDisplayed(), "Categories not working as expected");

        driver.close();
    }



}
