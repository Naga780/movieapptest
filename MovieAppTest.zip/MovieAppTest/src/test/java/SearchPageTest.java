import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.SearchPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;


public class SearchPageTest {
    public static WebDriver driver;
    public SearchPage searchPageTest;


    @BeforeMethod
    public void Setup(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Naga\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech");
        searchPageTest = new SearchPage(driver);

    }

    @AfterMethod
    public void Setdown(){
        driver.quit();
    }

    @Test
     public void searchingsomMovies(){
        searchPageTest.LogintToApplication("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        WebElement searchElm = driver.findElement(By.className("search-empty-button"));
        searchElm.click();

        String ExpectedUrl = "https://qamoviesapp.ccbp.tech/search";

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.urlToBe(ExpectedUrl));

        String currentUrl = driver.getCurrentUrl();

        if(ExpectedUrl.equals(currentUrl)){
            System.out.println("Navigated to search page Successfully");
        }
    }

    @Test
    public void searchMoviesInSearchBtn(){
        searchPageTest.LogintToApplication("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        WebElement searchElm = driver.findElement(By.className("search-empty-button"));
        searchElm.click();

        WebElement searchInput = driver.findElement(By.className("search-input-field"));
        searchInput.sendKeys("Dune");

        WebElement clicksearchBtn = driver.findElement(By.className("search-button"));
        clicksearchBtn.click();
    }

}
