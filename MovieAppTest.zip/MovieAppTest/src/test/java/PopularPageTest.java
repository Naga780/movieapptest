import org.openqa.selenium.support.ui.ExpectedConditions;
import pages.PopularPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class PopularPageTest {
    public static WebDriver driver;
    public PopularPage popularpage;


    @BeforeMethod
    public void Setup(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Naga\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://qamoviesapp.ccbp.tech");
        popularpage = new PopularPage(driver);

    }

    @AfterMethod
    public void Setdown(){
        driver.quit();
    }

    @Test
    public void topopularpage(){
        popularpage.LogintToApplication("rahul", "rahul@2021");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        WebElement popularBtn = driver.findElement(By.xpath("/html/body/div/div/div[1]/nav/div[1]/ul/li[2]/a"));
        popularBtn.click();

        String expectedUrl = "https://qamoviesapp.ccbp.tech/popular";
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        wait.until(ExpectedConditions.urlToBe(expectedUrl));
        String currentUrl = driver.getCurrentUrl();

        if( expectedUrl.equals(currentUrl)){
            System.out.println("The movies are displayed");
        }

    }
}
